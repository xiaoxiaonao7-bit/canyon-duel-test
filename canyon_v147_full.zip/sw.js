/* 峽谷對決 1.4.7 Service Worker
   策略：安裝時預快取核心檔；導航請求 cache-first + 離線回 index.html；
   其他同源 GET 走 cache-first，miss 才回網路。 */
const VERSION = 'gvd-147-v2';
const CORE = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(VERSION);
    // 逐檔加入，任何一個失敗都不影響其他（大檔 index.html 可能較慢）
    await Promise.all(CORE.map(async (u) => {
      try { await c.add(new Request(u, { cache: 'reload' })); } catch (err) {}
    }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  // 導航請求：先快取（index.html），沒有才上網
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    e.respondWith((async () => {
      const cache = await caches.open(VERSION);
      const hit = await cache.match('./index.html') || await cache.match('./');
      if (hit) return hit;
      try { return await fetch(req); }
      catch (_) { return new Response('離線中，請連網後再開一次。', { headers: { 'content-type': 'text/plain; charset=utf-8' } }); }
    })());
    return;
  }

  e.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req);
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && res.ok) cache.put(req, res.clone());
      return res;
    } catch (_) { return hit || Response.error(); }
  })());
});
